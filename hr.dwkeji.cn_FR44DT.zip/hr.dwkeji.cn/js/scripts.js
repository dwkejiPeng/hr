document.addEventListener('DOMContentLoaded', function() {
    // Add event listeners or any initialization code here
});
